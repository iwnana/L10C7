for(let i = 1; i < 51; i++){
  if(i % 4 == 0) {
    console.log('4で割れる数です。' + i);
  }

  if(i == 10) {
    console.log('今' + i + '回ループしました。');
  }

  if(i == 20) {
    console.log('今' + i + '回ループしました。');
  }

  if(i == 30) {
    console.log('今' + i + '回ループしました。');
  }

  if(i == 40) {
    console.log('今' + i + '回ループしました。');
  }

  if(i == 50) {
    alert(i + '回カウントが終わりました。');
  }
}